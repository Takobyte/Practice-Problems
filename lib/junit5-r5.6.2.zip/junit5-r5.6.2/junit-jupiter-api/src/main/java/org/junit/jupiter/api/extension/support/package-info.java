/**
 * JUnit Jupiter API support for writing extensions.
 */

package org.junit.jupiter.api.extension.support;
